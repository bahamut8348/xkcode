//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EZSkinDemo.rc
//
#define IDC_CAPTION1                    101
#define IDD_EZSKINDEMO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDD_DCDUMP_DLG                  130
#define IDB_TREE                        136
#define IDB_CAPTION                     137
#define IDB_BACK                        138
#define IDB_LABEL                       140
#define IDB_BTNSH                       141
#define IDB_BTNS                        142
#define IDI_FOLDER_CLOSED               143
#define IDI_FOLDER_OPEN                 144
#define IDC_LIST1                       1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
