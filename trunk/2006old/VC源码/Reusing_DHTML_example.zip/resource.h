//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dhtml2.rc
//
#define IDD_DHTML2_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDR_HTML1                       129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     131
#define IDR_HTML2                       132
#define IDR_HTML3                       133
#define IDR_HTML4                       135
#define IDC_STATIC1                     1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
